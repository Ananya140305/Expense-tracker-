package com.servlet.receipt;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/login")
public class ReceiptServlet extends HttpServlet {
    //query
	private static final String INSERT_QUERY = "INSERT INTO Users(username,password) VALUES(?,?)";
	
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
        System.out.println("doGet method called");
        
        PrintWriter pw = res.getWriter();
        res.setContentType("text/html");
        // Get the receipt amount parameter
        String Username = req.getParameter("username");
        String Password = req.getParameter("password");
        
        System.out.println("Username:" + Username);
        System.out.println("Password:" + Password);
        
        
        try {
        	Class.forName("com.mysql.cj.jdbc.Driver");
        }catch(ClassNotFoundException e) {
        	e.printStackTrace();
        }
        
        try(Connection con = DriverManager.getConnection("jdbc:mysql:///expense_tracker","root","1234");
        		PreparedStatement ps = con.prepareStatement(INSERT_QUERY);){
        	//set values 
        	ps.setString(1, Username);
        	ps.setString(2, Password);
        	
        	//execute
        	int count = ps.executeUpdate();
        	
        	if(count == 0) {
        		pw.println("Record Not Stored");
        	}
        	else {
        		res.sendRedirect("dashboard.html");
        	}
        }catch(SQLException se) {
        	pw.println(se.getMessage());
        	se.printStackTrace();
        }catch(Exception e){
        	pw.println(e.getMessage());
        	e.printStackTrace();
        	
        }
        pw.close();
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }
}
