
document.addEventListener('DOMContentLoaded', () => {
    // Initialize the chart
    const ctx = document.getElementById('expenseGraph').getContext('2d');
    const expenseGraph = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov'],
            datasets: [{
                label: 'Expenses',
                data: [2000, 3000, 1500, 5000, 2500, 4000],
                borderColor: 'rgba(255, 99, 132, 1)',
                borderWidth: 2,
                fill: false,
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true,
                    position: 'top',
                }
            }
        }
    });

    // Handle budget form submission
    const budgetForm = document.getElementById('budget-form');
    budgetForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const totalBudget = document.getElementById('total-budget').value;
        alert(`Total budget set to: ₹${totalBudget}`);
    });
});
